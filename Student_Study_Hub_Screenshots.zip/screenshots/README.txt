Student Study Hub screenshots

Figure-1-Dashboard.png — Dashboard page.
Figure-2-Assignments.png — Assignments page.
Figure-3-Study-Schedule.png — Study schedule page.

Add your remaining Study Materials and Settings screenshots to this folder if available.
