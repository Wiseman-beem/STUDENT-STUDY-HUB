# Student Study Hub

Student Study Hub is a student-focused website prototype designed to help students organise their academic activities. The prototype includes a dashboard, assignment tracking, a study schedule, study materials, and settings.

## Project purpose

The purpose of this project is to demonstrate interaction design principles through a simple interface that helps students access study-planning features in one place.

## Files

- `index.html` — the website prototype. Open this file in a web browser to view it.
- `Student_Study_Hub_Part2_Report_with_Table_of_Contents.docx` — the Part 2 research report.
- `screenshots/` — place screenshots of the actual website prototype here.

## How to open the prototype

Download or clone the repository, then open `index.html` in a web browser. This is a front-end prototype; features that require a server, database, real user accounts, or automatic notifications are not connected unless implemented separately.

## Screenshots

Add screenshots of the actual dashboard and any other prototype pages to the `screenshots` folder before submission.
